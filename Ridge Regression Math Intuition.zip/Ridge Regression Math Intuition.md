### Ridge Regression:
    Everything same like LinearRegression but the main difference is in cost function. In Ridge Regression in 
    cost function we need to add (lambda*sqr(slope)). 


```python
from IPython.display import Image
```


```python
Image(filename=('/home/hasan/Pictures/a1.png'))
```




![png](output_2_0.png)




```python

```


```python
#Formula of best fit line
Image(filename=('/home/hasan/Pictures/a2.png'))
```




![png](output_4_0.png)




```python

```


```python
# Gradient Descent of Ridge Regression
Image(filename=('/home/hasan/Pictures/a3.png'))
```




![png](output_6_0.png)




```python

```


```python

```


```python
#convergence theorem
Image(filename=('/home/hasan/Pictures/a7.png'))
```




![png](output_9_0.png)



Cost function in ridge regression is everythong same but need to add (lambda*sqr(slojpe)) with cost function 
to reduce overfitting. 


```python

```
